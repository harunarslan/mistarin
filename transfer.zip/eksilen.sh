#!/bin/bash

sa=($(ls /root/target/ | wc -l))
sa2=($(ls /root/paid/ | wc -l))
echo -e "\e[3;36m Service Accounts Sayisi: $sa \e[0m"
echo -e "\e[3;36m Service Accounts2 Sayisi: $sa2 \e[0m"

index=100
index2=200

while :
do
  index=$(($index - 1))
  if [[ $index -lt 1 ]]; then
    index=100
  fi

index2=$(($index2 - 1))
  if [[ $index2 -lt 1 ]]; then
    index=200
  fi
	
rclone backend set baranbro: -o service_account_file="/root/target/$index.json"
rclone backend set baromazo: -o service_account_file="/root/paid/$index2.json"

fusermount -uz /root/baromazo
fusermount -uz /root/baranbro

rclone mount baromazo: /root/baromazo --vfs-cache-mode off --daemon --multi-thread-streams 30 --low-level-retries 2 --retries 2 --vfs-read-chunk-size 128K --drive-chunk-size 1M --buffer-size off --max-backlog 20000 --contimeout 9s --no-traverse --no-modtime --log-level INFO --stats 1m
rclone mount baranbro: /root/baranbro --vfs-cache-mode off --daemon --multi-thread-streams 30 --low-level-retries 2 --retries 2 --vfs-read-chunk-size 128K --drive-chunk-size 1M --buffer-size off --max-backlog 20000 --contimeout 9s --no-traverse --no-modtime --log-level INFO --stats 1m

echo "********************************************************"
echo -e "\e[3;32m Service Account Değişti: $index \e[0m" 
echo -e "\e[3;32m Service Account2 Değişti: $index2 \e[0m" 
echo -e "\e[3;31m 1 Saatlik Uyku Moduna Giriliyor ... \e[0m"
echo "********************************************************"
echo "$(date)"
sleep 3600
done
