#!/bin/bash
files=($(ls /root/baromazo/data2/ ))
index=0
deneme=0
while :
do
sayi=0
sayi=($(ls /root/baromazo/data2/ | wc -l))
echo -e "\e[3;36m Plot Sayisi: $sayi \e[0m"
for (( i = 0; i <= $sayi; i++ ))
do
index=$(($index + 1))
if [[ $index -gt 200 ]]; then
index=1
fi

deneme=$(($deneme + 1))
echo -e "\e[3;31m Deneme: $deneme \e[0m"
echo -e "\e[3;32m Plot Transferi Baslatiliyor ... \e[0m"

echo -e "\e[3;35m Rclone Backend Degisti \n \e[0m"
rclone backend set baromazo: -o service_account_file="/root/paid/$index.json"

echo -e "\e[3;32m Aktarılıyor: \e[0m" ${files[$i]} 
rclone copy /root/baromazo/data2/${files[$i]} baranbro:data  --drive-chunk-size 1024M --no-traverse --min-size 49G --checkers 3 --tpslimit 3 --transfers 3 --fast-list --drive-server-side-across-configs -P;
echo -e "\e[3;31m Program Döngüsü Bitti ... \e[0m"
echo "********************************************************"
sleep 5
done
sleep 100
done


