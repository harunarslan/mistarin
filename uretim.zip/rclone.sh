index=1
deneme=0
while :
do
deneme=$(($deneme + 1))
echo -e "\e[3;31m Deneme: $deneme \e[0m"
echo ""

sayi=0
sayi=($(ls /root/nvme/plot/ | wc -l))
echo -e "\e[3;36m Plot Sayisi: $sayi \e[0m"
echo -e "\e[3;36m Serice Account: $index \e[0m"
echo " "

if [[ $sayi -gt 0 ]]; then
index=$index
if [[ $index -gt 99 ]]; then
index=1
fi

echo -e "\e[3;32m Plot Transferi Baslatiliyor ... \e[0m"
rclone backend set noecy: -o service_account_file="/root/.config/rclone/accounts/$index.json"
echo -e "\e[1;33m Rclone Backend Degisti \n \e[0m"
rclone move /root/nvme/plot/ noecy:main --drive-chunk-size 1024M --min-size 49G --checkers 3 --tpslimit 3 --transfers 3 --no-traverse --fast-list --drive-server-side-across-configs -P;
index=$(($index + 1))
echo -e "\e[3;32m Program Döngüsü Bitti ... \e[0m"
echo "********************************************************"
fi
sleep 300
done