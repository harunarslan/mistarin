#!/bin/bash

cd /
sudo parted /dev/nvme0n1 --script mklabel gpt mkpart xfspart xfs 0% 100%
sudo mkfs.xfs -f /dev/nvme0n1
sudo partprobe /dev/nvme0n1
sudo mount /dev/nvme0n1 /root/nvme