#!/bin/bash

THREADS="$(nproc)"
SERVICE="./build/chia_plot"
TEMP="/root/nvme/temp/"
TEMP2="/root/nvme/temp2/"
PLOT="/root/nvme/plot/"
PPK="935f4eb2558bdb636b21a8a0d7dc008ca61eac47e0a65c51f8b2b8befc9e562faf8b42dca3a255e7a1eb5db94705dfda"
FPK="98335c4f087d0ce7a361e9e68c0e850fe40029c9ec2cb8c710c62e9bea530ea9fbb5a09894563fcf3d8f50bdedd59526"

while : 
    do 
        $SERVICE -n -1 -r $THREADS -t $TEMP -2 $TEMP2 -d $PLOT -p $PPK -f $FPK -k 31 -x 9699 
    done
    