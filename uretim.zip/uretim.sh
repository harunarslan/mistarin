curl https://rclone.org/install.sh | sudo bash
mkdir .config
mkdir .config/rclone
mv accounts/ /root/.config/rclone
mv rclone.conf /root/.config/rclone
mkdir .uretim
mv nvme.sh /root/.uretim
mv rclone.sh /root/.uretim
#BU KOD KLASÖRÜN İÇİNDEKİ DOSYALARI 1-100 SAYI ATAR
#ls -v | cat -n | while read n f; do mv -n "$f" "$n.json"; done
cd
mkdir nvme
cd /root/nvme
mkdir temp
mkdir temp2
mkdir plot
chmod 777 temp
chmod 777 temp2
chmod 777 plot

cd /root/.uretim
chmod 777 nvme.sh
chmod a+w nvme.sh
chmod +x nvme.sh
sudo bash nvme.sh
chmod 777 rclone.sh
screen -dmS rclone bash rclone.sh

cd
sudo apt install -y libsodium-dev cmake g++ git build-essential
sudo apt-get install build-essential cmake
git clone https://github.com/madMAx43v3r/chia-plotter.git /root/madmax
mv madmax.sh /root/madmax

cd /root/madmax
chmod 777 madmax.sh
git submodule update --init
./make_devel.sh
sleep 3
screen -dmS madmax bash madmax.sh
rm -r /root/mistarin



